# Leo — Personal Portfolio

A responsive, single-page personal portfolio built with plain HTML, CSS and JavaScript.

## Run locally
Open `index.html` in a browser.

## Publish free with GitHub Pages
1. Create a public repository named `leoshylack06-lab.github.io` under your GitHub account.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. Wait for deployment. Your site should appear at `https://leoshylack06-lab.github.io`.

You can also deploy the same folder using Cloudflare Pages and its free `pages.dev` subdomain.

## Personalise before publishing
- Confirm the public name you want displayed.
- Add a professional contact email only if you want it public.
- Replace project descriptions if project status changes.
- Do not publish private phone numbers, home address, passwords, API keys or other sensitive details.
